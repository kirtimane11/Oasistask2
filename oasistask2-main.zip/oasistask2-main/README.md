# oasis_task_2
# Created the portfolio using html and css
